package com.example.condominioapp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserLogin {
    public static boolean check(String nombre, String contraseña) throws SQLException {
        String sql = "SELECT * FROM users WHERE nombre = ? AND contraseña = ?";

        Connection conn = Conexion.open();
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(1, nombre);
        statement.setString(2, contraseña);
        ResultSet resultSet = statement.executeQuery();
        boolean result = resultSet.next();
        resultSet.close();
        statement.close();
        Conexion.close();
        return result;
    }
}
