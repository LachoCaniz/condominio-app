package com.example.condominioapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.SQLException;

public class MainActivity extends AppCompatActivity {
    private void cambiaActivity(){
        Intent i = new Intent(this, Registro.class);
        startActivity(i);
    };
    private void cambiaActivityMenu(){
        Intent i = new Intent(this, ListActivity.class);
        startActivity(i);
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonSignIn = findViewById(R.id.button_login);

        final SharedPreferences preferences = getSharedPreferences("user_preferences", MODE_PRIVATE);
        final String username = preferences.getString("username", null);
        final String password = preferences.getString("password", null);


        buttonSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editNombre = findViewById(R.id.Main_edit_email);
                EditText editPassword = findViewById(R.id.Main_edit_password);

                String nombre = editNombre.getText().toString();
                String contraseña = editPassword.getText().toString();

                if ((nombre.equals(username)&&contraseña.equals(password))){
                    cambiaActivityMenu();
                }else{
                   // Toast.makeText(MainActivity.this, "Datos Incorrectos", Toast.LENGTH_SHORT).show();
                    Toast.makeText(MainActivity.this, "Datos Incorrectos", Toast.LENGTH_SHORT).show();
                }

            }
        });


        Button botonRegistro = findViewById(R.id.Login_button_signup);
        botonRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cambiaActivity();
                //Toast.makeText(MainActivity.this, "Intent a Registro", Toast.LENGTH_SHORT).show();

            }
        });




    }

}
