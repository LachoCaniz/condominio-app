package com.example.condominioapp;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class Conexion {
    private static final String URL = "jdbc:mysql://localhost:3306";
    private static final String USERNAME = "id19019341_usuario";
    private static final String PASSWORD = "Horaciocaniz#7";

    private static Connection conn;

    public static Connection open() throws SQLException {
        conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        return conn;
    }

    public static void close() throws SQLException {
        if (conn != null) {
            conn.close();
        }
    }
}
