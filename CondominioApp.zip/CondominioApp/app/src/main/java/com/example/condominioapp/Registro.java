package com.example.condominioapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.SQLException;

public class Registro extends AppCompatActivity {

    private void cambiaActivityMenu(){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }

    private boolean validateInputs(String username, String password){
        return !username.isEmpty()&&!password.isEmpty();
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        Button botonRegistro = findViewById(R.id.Registro_button_signup);

        botonRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editNombre = findViewById(R.id.edit_nombre);
                EditText editApellido = findViewById(R.id.edit_apellido);
                EditText editDireccion = findViewById(R.id.edit_direccion);
                EditText editEmail = findViewById(R.id.edit_email);
                EditText editPassword = findViewById(R.id.edit_password);
                TextView tvError= findViewById(R.id.Registro_textview_Error);

                String nombre = editNombre.getText().toString();
                String apellido = editApellido.getText().toString();
                String direccion = editDireccion.getText().toString();
                String email = editEmail.getText().toString();
                String contraseña = editPassword.getText().toString();

                if (validateInputs(nombre,contraseña)){
                    RegistroUsuario user = new RegistroUsuario (nombre, contraseña);
                    SharedPreferences preferences = getSharedPreferences("user_preferences", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("username", user.getmUsername());
                    editor.putString("password", user.getmPassword());
                    editor.apply();
                    Toast.makeText(Registro.this, "Registro Exitoso", Toast.LENGTH_SHORT).show();
                    cambiaActivityMenu();
                    finish();
                }else {
                    Toast.makeText(Registro.this, "Ingrese todos los campos", Toast.LENGTH_SHORT).show();
                }
            /*
                try {
                    cambiaActivityMenu();
                    //Toast.makeText(Registro.this, "Se ha registrado correctamente", Toast.LENGTH_SHORT).show();
                    RegistroUsuario.insert(nombre, apellido, direccion, email, contraseña);
                } catch (SQLException e) {
                    tvError.setText("El Error es: "+ e);
                    e.printStackTrace();
                }
             */
            }
        }
        );




    }
}