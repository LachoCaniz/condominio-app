package com.example.condominioapp;
import android.os.Bundle;
import android.widget.EditText;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegistroUsuario {
    private String mUsername;
    private String mPassword;


    public RegistroUsuario(String username, String password) {
        mUsername = username;
        mPassword = password;

    }

    public String getmUsername() {
        return mUsername;
    }

    public void setmUsername(String mUsername) {
        this.mUsername = mUsername;
    }

    public String getmPassword() {
        return mPassword;
    }

    public void setmPassword(String mPassword) {
        this.mPassword = mPassword;
    }

}
